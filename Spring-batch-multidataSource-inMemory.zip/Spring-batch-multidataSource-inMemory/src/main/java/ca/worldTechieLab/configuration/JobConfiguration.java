package ca.worldTechieLab.configuration;

import ca.worldTechieLab.mapper.RetAdvUserRowMapper;
import ca.worldTechieLab.model.RetAdvUserModel;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.item.database.support.SqlServerPagingQueryProvider;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.batch.item.support.CompositeItemWriter;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;

import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.JdbcPagingItemReader;
import org.springframework.batch.item.database.Order;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;


@Configuration
public class JobConfiguration {
    @Autowired
    private JobBuilderFactory jobBuilderFactory;
    @Autowired
    private StepBuilderFactory stepBuilderFactory;
    @Autowired
    @Qualifier("primarySource")
    private DataSource dataSource;
    @Autowired
    @Qualifier("sqlServerDataSource")
    private DataSource sqlServerDataSource;
    @Autowired
    @Qualifier("db2DataSource")
    private  DataSource db2DataSource;
    @Autowired
    private Db2Writer db2Writer;


    @Bean
    public JdbcPagingItemReader<RetAdvUserModel> customerPagingItemReader() {
        // reading database records using JDBC in a paging fashion
        JdbcPagingItemReader<RetAdvUserModel> reader = new JdbcPagingItemReader<>();
        reader.setDataSource(this.sqlServerDataSource);
        reader.setFetchSize(1000);
        reader.setRowMapper(new RetAdvUserRowMapper());
        // Sort Keys
        Map<String, Order> sortKeys = new HashMap<>();
        sortKeys.put("USERID", Order.ASCENDING);
        // MySQL implementation of a PagingQueryProvider using database specific features.
        SqlServerPagingQueryProvider queryProvider = new SqlServerPagingQueryProvider();
        queryProvider.setSelectClause("UP.USERID,UT.USERKEY,UP.EARNINGSAMT");
        queryProvider.setFromClause("from RETADV_USER_PROFILES UP join RETADV_USER_TRANSLATION UT ON UP.USERID =UT.USERID");
                queryProvider.setWhereClause("UP.USERID=112");
//        queryProvider.setWhereClause("NEWVERSIONFIRSTVISIT='true'");
        queryProvider.setSortKeys(sortKeys);
        reader.setQueryProvider(queryProvider);
        return reader;
    }





    @Bean
    public FlatFileItemWriter<RetAdvUserModel> csvwriter(){
        FlatFileItemWriter<RetAdvUserModel> writer = new FlatFileItemWriter<RetAdvUserModel>();
        writer.setResource(new ClassPathResource("RetAdvOutput.csv"));
        writer.setLineAggregator(new DelimitedLineAggregator<RetAdvUserModel>() {{
            setDelimiter(",");
            setFieldExtractor(new BeanWrapperFieldExtractor<RetAdvUserModel>() {{
                setNames(new String[] { "userId", "userKey","earningAmount" });
            }});
        }});

        return writer;
    }




    @Bean
    public CompositeItemWriter<RetAdvUserModel> itemWriter() throws Exception {
        List<ItemWriter<? super RetAdvUserModel>> writers = new ArrayList<>();
        writers.add(csvwriter());
        writers.add(db2Writer);
        CompositeItemWriter<RetAdvUserModel> compositeItemWriter = new CompositeItemWriter<>();
        compositeItemWriter.setDelegates(writers);
        compositeItemWriter.afterPropertiesSet();
        return compositeItemWriter;
    }

    @Bean
    public Step step1() throws Exception {
        return stepBuilderFactory.get("step1")
                .<RetAdvUserModel, RetAdvUserModel>chunk(10)
                .reader(customerPagingItemReader())
                .writer(itemWriter())
                .build();
    }

    @Bean
    public Job job() throws Exception {
        return jobBuilderFactory.get("job")
                .start(step1())
                .build();
    }
}
