package ca.worldTechieLab.configuration;

import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;

@Component
public class BatchConfig  {

    @Bean(name = "primarySource")
    @Primary
    public DataSource primarySource() {
        return DataSourceBuilder.create()
                .url("jdbc:h2:mem:testdb")
                .driverClassName("org.h2.Driver")
                .username("sa")
                .password("password")
                .build();
    }

    @Bean(name = "sqlServerDataSource")
    public DataSource sqlServerDataSource() {
        return DataSourceBuilder.create()
                .url("jdbc:sqlserver://localhost:8480\\worldtechieLab;DatabaseName=Test;sendStringParametersAsUnicode=false")
                .driverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver")
                .username("username")
                .password("Password")
                .build();
    }

}
