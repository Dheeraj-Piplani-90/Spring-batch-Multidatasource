package ca.worldTechieLab.configuration;

import ca.worldTechieLab.entity.MemberSalaryEntity;
import ca.worldTechieLab.model.RetAdvUserModel;
import ca.worldTechieLab.repository.IMemberSalaryRepository;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Component
public class Db2Writer implements ItemWriter<RetAdvUserModel> {

    @Autowired
     private IMemberSalaryRepository grsMbrRepo;

    @Override
    public void write(List<? extends RetAdvUserModel> list) throws Exception {
        String userKey;
        String clientId;
        String planId;
        String memberNumber;
        String memberType;
        for(RetAdvUserModel retAdvUserModel:list){
            userKey=retAdvUserModel.getUserKey();
            clientId=userKey.split("-")[0];
            planId=userKey.split("-")[1];
            memberNumber=userKey.split("-")[2];
            memberType=userKey.split("-")[3];
               Long records=grsMbrRepo.findByClientIdAndPlanIdAndMemberNumber(clientId,planId,memberNumber,memberType);
          if(records==null || records<1){
              insertRecord(clientId,planId,memberNumber,memberType,retAdvUserModel.getEarningAmount());
          }
        }
    }

    private MemberSalaryEntity insertRecord(String clientId,String planId,String memberNumber,String memberType,double earningAmount){
        MemberSalaryEntity grsMbrSalary = new MemberSalaryEntity();
        grsMbrSalary.setVersionNumber(1);
        grsMbrSalary.setClientId(clientId);
        grsMbrSalary.setPlanId(planId);
        grsMbrSalary.setMemberNumber(memberNumber);
        grsMbrSalary.setMemberTypeCode(memberType);
        grsMbrSalary.setSalaryTypeCode("A");
        grsMbrSalary.setAnnualSalary(earningAmount);
        grsMbrSalary.setRatePerHourAmount(0);
        grsMbrSalary.setHourPerWeekNumber(0);
        grsMbrSalary.setPayPeriodNumber(26);
        DateFormat dateFormat = new SimpleDateFormat("YYYYMMdd");
        String strDate = dateFormat.format(new Date());
        grsMbrSalary.setUpdateUserName("SWEEP-" + strDate);
        return grsMbrRepo.save(grsMbrSalary);
    }
}
