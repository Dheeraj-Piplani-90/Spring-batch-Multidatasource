package ca.worldTechieLab.mapper;

import ca.worldTechieLab.model.RetAdvUserModel;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class RetAdvUserRowMapper implements RowMapper<RetAdvUserModel> {

    @Override
    public RetAdvUserModel mapRow(ResultSet rs, int rowNum) throws SQLException {
        return RetAdvUserModel.builder().userId(rs.getLong("USERID"))
                .userKey(rs.getString("USERKEY").replaceAll(" ", ""))
                .earningAmount(rs.getDouble("EARNINGSAMT")).build();
    }
}