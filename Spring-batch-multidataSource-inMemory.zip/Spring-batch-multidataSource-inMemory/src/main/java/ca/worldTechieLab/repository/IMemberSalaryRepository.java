package ca.worldTechieLab.repository;

import ca.worldTechieLab.entity.MemberSalaryEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface IMemberSalaryRepository extends JpaRepository<MemberSalaryEntity,Long> {

    @Query("SELECT count(*) FROM MemberSalaryEntity as memberSalary "
            + "WHERE memberSalary.clientId = :clientId AND memberSalary.planId = :planId "
            + "AND memberSalary.memberNumber =:memberNumber AND memberSalary.memberTypeCode = :memberType ")
    public Long findByClientIdAndPlanIdAndMemberNumber(@Param("clientId") String clientId,
                                                                     @Param("planId") String planId, @Param("memberNumber") String memberNumber,@Param("memberType") String memberType);
}
