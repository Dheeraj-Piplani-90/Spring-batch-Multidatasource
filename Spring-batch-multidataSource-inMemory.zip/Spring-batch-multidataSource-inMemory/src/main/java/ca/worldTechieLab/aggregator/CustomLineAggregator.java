package ca.worldTechieLab.aggregator;
import ca.worldTechieLab.model.RetAdvUserModel;
import org.springframework.batch.item.file.transform.LineAggregator;
import com.fasterxml.jackson.databind.ObjectMapper;
public class CustomLineAggregator implements LineAggregator<RetAdvUserModel> {
    private ObjectMapper objectMapper = new ObjectMapper();
    @Override
    public String aggregate(RetAdvUserModel item) {
        try {
            return objectMapper.writeValueAsString(item);
        } catch (Exception e) {
            throw new RuntimeException("Unable to serialize Customer", e);
        }
    }
}
