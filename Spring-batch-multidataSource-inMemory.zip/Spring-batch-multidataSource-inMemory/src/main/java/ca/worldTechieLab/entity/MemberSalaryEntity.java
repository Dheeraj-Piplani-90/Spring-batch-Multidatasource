package ca.worldTechieLab.entity;

import javax.persistence.*;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;


import java.sql.Timestamp;
import java.util.Calendar;

@Entity
@Table(name = MemberSalaryEntity.GRS_MBR_SALARY_T)
public class MemberSalaryEntity  {

	public static final String GRS_MBR_SALARY_T = "GRS_MBR_SALARY_T";
	public static final String MBR_SLRY_ID = "MBR_SLRY_ID";
	public static final String VERS_NUM = "VERS_NUM";
	public static final String CLI_ID = "CLI_ID";
	public static final String PLAN_ID = "PLAN_ID";
	public static final String MBR_NUM = "MBR_NUM";
	public static final String MBR_TYP_CD = "MBR_TYP_CD";
	public static final String SLRY_TYP_CD = "SLRY_TYP_CD";
	public static final String ANN_SLRY_AMT = "ANN_SLRY_AMT";
	public static final String RATE_PER_HR_AMT = "RATE_PER_HR_AMT";
	public static final String HR_PER_WK_NUM = "HR_PER_WK_NUM";
	public static final String PAY_PERI_NUM = "PAY_PERI_NUM";
	public static final String PREV_UPDT_USER_ID = "PREV_UPDT_USER_ID";
	public static final String PREV_UPDT_TMSTMP = "PREV_UPDT_TMSTMP";

	/** Default serial version id. */
	private static final long serialVersionUID = 1L;
	private long memberSalaryId;
	private int versionNumber;
	private String clientId;
	private String planId;
	private String memberNumber;
	private String memberTypeCode;
	private String salaryTypeCode;
	private double annualSalary;
	private double ratePerHourAmount;
	private double hourPerWeekNumber;
	private int payPeriodNumber;
	/** Attribute - Last update user name. */
	private String updateUserName;
	/** Attribute - Last update time stamp. */
	private Timestamp updateTimestamp;

	private boolean autoUpdateTimestamp = true;

	/**
	 * @return the memberSalaryId
	 */
	@Id
	@GenericGenerator(name = "memberSalarySequenceGenerator", strategy = "org.hibernate.id.SequenceGenerator", parameters = {
			@Parameter(name = "sequence", value = "MBR_SLRY_ID_S") })
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "memberSalarySequenceGenerator")
	@Column(name = MBR_SLRY_ID, nullable = false)
	public long getMemberSalaryId() {
		return memberSalaryId;
	}

	/**
	 * @return the versionNumber
	 */
	@Column(name = VERS_NUM)
	public int getVersionNumber() {
		return versionNumber;
	}

	/**
	 * @return the clientId
	 */
	@Column(name = CLI_ID)
	public String getClientId() {
		return clientId;
	}

	/**
	 * @return the planId
	 */
	@Column(name = PLAN_ID)
	public String getPlanId() {
		return planId;
	}

	/**
	 * @return the memberNumber
	 */
	@Column(name = MBR_NUM)
	public String getMemberNumber() {
		return memberNumber;
	}

	/**
	 * @return the memberTypeCode
	 */
	@Column(name = MBR_TYP_CD)
	public String getMemberTypeCode() {
		return memberTypeCode;
	}

	/**
	 * @return the salaryTypeCode
	 */
	@Column(name = SLRY_TYP_CD)
	public String getSalaryTypeCode() {
		return salaryTypeCode;
	}

	/**
	 * @return the annualSalary
	 */
	@Column(name = ANN_SLRY_AMT)
	public double getAnnualSalary() {
		return annualSalary;
	}

	/**
	 * @return the ratePerHourAmount
	 */
	@Column(name = RATE_PER_HR_AMT)
	public double getRatePerHourAmount() {
		return ratePerHourAmount;
	}

	/**
	 * @return the hourPerWeekNumber
	 */
	@Column(name = HR_PER_WK_NUM)
	public double getHourPerWeekNumber() {
		return hourPerWeekNumber;
	}

	/**
	 * @return the payPeriodNumber
	 */
	@Column(name = PAY_PERI_NUM)
	public int getPayPeriodNumber() {
		return payPeriodNumber;
	}

	/**
	 * @param memberSalaryId
	 *            the memberSalaryId to set
	 */
	public void setMemberSalaryId(long memberSalaryId) {
		this.memberSalaryId = memberSalaryId;
	}

	/**
	 * @param versionNumber
	 *            the versionNumber to set
	 */
	public void setVersionNumber(int versionNumber) {
		this.versionNumber = versionNumber;
	}

	/**
	 * @param clientId
	 *            the clientId to set
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	/**
	 * @param planId
	 *            the planId to set
	 */
	public void setPlanId(String planId) {
		this.planId = planId;
	}

	/**
	 * @param memberNumber
	 *            the memberNumber to set
	 */
	public void setMemberNumber(String memberNumber) {
		this.memberNumber = memberNumber;
	}

	/**
	 * @param memberTypeCode
	 *            the memberTypeCode to set
	 */
	public void setMemberTypeCode(String memberTypeCode) {
		this.memberTypeCode = memberTypeCode;
	}

	/**
	 * @param salaryTypeCode
	 *            the salaryTypeCode to set
	 */
	public void setSalaryTypeCode(String salaryTypeCode) {
		this.salaryTypeCode = salaryTypeCode;
	}

	/**
	 * @param annualSalary
	 *            the annualSalary to set
	 */
	public void setAnnualSalary(double annualSalary) {
		this.annualSalary = annualSalary;
	}

	/**
	 * @param ratePerHourAmount
	 *            the ratePerHourAmount to set
	 */
	public void setRatePerHourAmount(double ratePerHourAmount) {
		this.ratePerHourAmount = ratePerHourAmount;
	}

	/**
	 * @param hourPerWeekNumber
	 *            the hourPerWeekNumber to set
	 */
	public void setHourPerWeekNumber(double hourPerWeekNumber) {
		this.hourPerWeekNumber = hourPerWeekNumber;
	}

	/**
	 * @param payPerNumber
	 *            the payPerNumber to set
	 */
	public void setPayPeriodNumber(int payPeriodNumber) {
		this.payPeriodNumber = payPeriodNumber;
	}

	@Column(name = PREV_UPDT_USER_ID, unique = false, nullable = false)
	public String getUpdateUserName() {
		return updateUserName;
	}

	public void setUpdateUserName(String updateUserName) {
		this.updateUserName = updateUserName;
	}

	@Column(name = PREV_UPDT_TMSTMP, unique = false, nullable = false)
	public Timestamp getUpdateTimestamp() {
		return updateTimestamp;
	}

	public void setUpdateTimestamp(Timestamp updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}

	/**
	 *
	 * @return true if timestamps will update automatically on save, false otherwise
	 * @see #onCreateOrUpdate()
	 */
	@Transient
	private boolean isAutoUpdateTimestamp() {
		return autoUpdateTimestamp;
	}

	/**
	 * Auto update of timestamps is on by default and causes the value to be updated
	 * with the current time on create or update, this method is only intended for
	 * use in data copy import.
	 *
	 * @param autoUpdateTimestamp
	 *            If false, will not override timestamp value on save or create.
	 * @see #onCreateOrUpdate
	 * @see #isAutoUpdateTimestamp()
	 */
	protected void setAutoUpdateTimestamp(boolean autoUpdateTimestamp) {
		this.autoUpdateTimestamp = autoUpdateTimestamp;
	}

	/**
	 * Automatically updates the timestamp value to the current date and time when
	 * an entity is being persisted (on create or update).
	 *
	 * @see #setAutoUpdateTimestamp(boolean)
	 * @see #isAutoUpdateTimestamp()
	 */
	@PrePersist
	@PreUpdate
	protected void onCreateOrUpdate() {
		if (isAutoUpdateTimestamp()) {
			this.updateTimestamp = new Timestamp(Calendar.getInstance().getTimeInMillis());
		}
	}

	public void touch() {
		this.updateTimestamp = null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MemberSalaryEntity [memberSalaryId=" + memberSalaryId + ", versionNumber=" + versionNumber
				+ ", clientId=" + clientId + ", planId=" + planId + ", memberNumber=" + memberNumber
				+ ", memberTypeCode=" + memberTypeCode + ", salaryTypeCode=" + salaryTypeCode + ", annualSalary="
				+ annualSalary + ", ratePerHourAmount=" + ratePerHourAmount + ", hourPerWeekNumber=" + hourPerWeekNumber
				+ ", payPerNumber=" + payPeriodNumber + "]";
	}

}
